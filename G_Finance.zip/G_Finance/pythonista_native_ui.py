#!/usr/bin/env python3
"""
G_Finance 100% Native Pythonista 3 iOS UI
=========================================
Pure UIKit native iOS user interface for Pythonista 3.
Zero webview, zero browser, zero local HTTP server required!

Features:
1. Native iOS TableViews:
   - Holdings list with live market values, gains/losses, dividend yields
   - Swipe actions, tap for holding detail card & buy/sell actions
   - Watchlist table with live prices & day changes
   - Transaction & sales history table
2. Native Vector Chart View:
   - Custom `ui.View` with `draw()` overriding using `ui.Path`
   - Gradient area fill, gridlines, reference line, high/low markers
   - Timeframe switcher (1D, 5D, 1M, 6M, YTD, 1Y, MAX)
   - Interactive touch crosshairs on iPhone / iPad screens
3. Portfolio Summary Card:
   - Total Portfolio Value, Cost Basis, Unrealized P/L ($ and %), Annual Dividends
   - Native portfolio switcher sheet (switch between USD, CAD, TFSA, RRSP, etc.)
4. Native iOS Financial Calculators:
   - Dividend & DRIP compounding simulator
   - Target sell price & breakeven calculator
   - Stock split calculator
5. Native Data Operations:
   - Add/Edit/Delete holdings directly with native iOS dialogs
   - Live quotes fetcher via Google / Yahoo Finance on background threads
   - Cloud Google Sheet sync with native iOS HUD alerts (console.hud_alert)
"""

from __future__ import annotations

import os
import sys
import time
import math
import threading
from typing import Dict, List, Any, Optional, Tuple

# Ensure working directory is in path
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)
try:
    os.chdir(BASE_DIR)
except Exception:
    pass

try:
    import ui
    PYTHONISTA_UI_AVAILABLE = True
except ImportError:
    ui = None
    PYTHONISTA_UI_AVAILABLE = False

try:
    import dialogs
except ImportError:
    dialogs = None

try:
    import console
except ImportError:
    console = None

# G_Finance backend modules
import csv_manager
from currency_converter import get_currency_converter
from google_finance_fetcher import GoogleFinanceFetcher
from chart_fetcher import get_chart_fetcher
import financial_calc
from google_sheet_sync import get_google_sheet_sync
from i18n import t

# Colors matching Apple iOS System Dark Theme
BG_COLOR = "#000000"
CARD_BG = "#1C1C1E"
CARD_SECONDARY = "#2C2C2E"
SEPARATOR_COLOR = "#38383A"
TEXT_PRIMARY = "#FFFFFF"
TEXT_SECONDARY = "#8E8E93"
ACCENT_BLUE = "#0A84FF"
ACCENT_GREEN = "#30D158"
ACCENT_RED = "#FF453A"
ACCENT_ORANGE = "#FF9F0A"


# =============================================================================
# 1. Native UIKit Interactive Vector Chart View
# =============================================================================
class NativeChartView(ui.View if ui else object):
    """Native iOS Chart rendered via UIKit draw() and ui.Path."""

    def __init__(self, *args, **kwargs):
        if ui:
            super().__init__(*args, **kwargs)
        self.prices: List[float] = []
        self.timestamps: List[Any] = []
        self.prev_close: float = 0.0
        self.currency_sym: str = "$"
        self.is_growth: bool = False
        self.touch_x: Optional[float] = None
        self.on_hover_callback = None
        self.background_color = CARD_BG
        self.corner_radius = 12

    def set_data(self, prices: List[float], timestamps: List[Any], prev_close: float, currency_sym: str = "$", is_growth: bool = False):
        self.prices = prices or []
        self.timestamps = timestamps or []
        self.prev_close = prev_close or (prices[0] if prices else 0.0)
        self.currency_sym = currency_sym
        self.is_growth = is_growth
        self.touch_x = None
        if hasattr(self, "set_needs_display"):
            self.set_needs_display()

    def draw(self):
        if not ui or not self.prices or len(self.prices) < 2:
            if ui:
                ui.set_color(TEXT_SECONDARY)
                font = ("<System>", 14)
                ui.draw_string(
                    "No chart data available for selected scope/timeframe.",
                    rect=(20, self.height * 0.45, self.width - 40, 30),
                    font=font,
                    color=TEXT_SECONDARY,
                    alignment=ui.ALIGN_CENTER,
                )
            return

        w, h = self.width, self.height
        pad_l, pad_r, pad_t, pad_b = 14, 55, 18, 25
        plot_w = w - pad_l - pad_r
        plot_h = h - pad_t - pad_b

        min_p = min(self.prices)
        max_p = max(self.prices)
        if self.prev_close > 0:
            min_p = min(min_p, self.prev_close)
            max_p = max(max_p, self.prev_close)

        p_range = max_p - min_p if max_p > min_p else max(1.0, max_p * 0.1)
        margin = p_range * 0.08
        min_p -= margin
        max_p += margin
        p_range = max_p - min_p

        # 1. Draw horizontal gridlines and Y labels
        n_grids = 4
        ui.set_color(SEPARATOR_COLOR)
        for i in range(n_grids + 1):
            val = min_p + (i / n_grids) * p_range
            gy = pad_t + plot_h - (i / n_grids) * plot_h
            line = ui.Path()
            line.move_to(pad_l, gy)
            line.line_to(pad_l + plot_w, gy)
            line.line_width = 0.5
            line.stroke()

            # Label on the right margin
            lbl_str = f"{self.currency_sym}{val:,.0f}" if val >= 1000 else f"{self.currency_sym}{val:,.2f}"
            ui.draw_string(
                lbl_str,
                rect=(pad_l + plot_w + 4, gy - 7, pad_r - 6, 14),
                font=("<System>", 9),
                color=TEXT_SECONDARY,
                alignment=ui.ALIGN_LEFT,
            )

        # 2. Draw previous close reference line
        if min_p <= self.prev_close <= max_p:
            ref_y = pad_t + plot_h - ((self.prev_close - min_p) / p_range) * plot_h
            ref_path = ui.Path()
            ref_path.move_to(pad_l, ref_y)
            ref_path.line_to(pad_l + plot_w, ref_y)
            ref_path.line_width = 1.0
            ref_path.set_line_dash([3, 3])
            ui.set_color("#636366")
            ref_path.stroke()

        # 3. Calculate points
        n_pts = len(self.prices)
        pts = []
        for i, p in enumerate(self.prices):
            px = pad_l + (i / (n_pts - 1)) * plot_w
            py = pad_t + plot_h - ((p - min_p) / p_range) * plot_h
            pts.append((px, py))

        curr_p = self.prices[-1]
        is_pos = (curr_p >= self.prev_close)
        line_color = ACCENT_GREEN if is_pos else ACCENT_RED
        fill_color = "#30D15822" if is_pos else "#FF453A22"

        # 4. Fill polygon under curve
        poly = ui.Path()
        base_y = pad_t + plot_h
        poly.move_to(pts[0][0], base_y)
        for x, y in pts:
            poly.line_to(x, y)
        poly.line_to(pts[-1][0], base_y)
        poly.close()
        ui.set_color(fill_color)
        poly.fill()

        # 5. Stroke line curve
        curve = ui.Path()
        curve.line_width = 2.0
        curve.move_to(pts[0][0], pts[0][1])
        for x, y in pts[1:]:
            curve.line_to(x, y)
        ui.set_color(line_color)
        curve.stroke()

        # 6. Interactive Touch Crosshair
        if self.touch_x is not None:
            # Clamp touch_x to plot area
            tx = max(pad_l, min(pad_l + plot_w, self.touch_x))
            frac = (tx - pad_l) / plot_w
            idx = int(round(frac * (n_pts - 1)))
            idx = max(0, min(n_pts - 1, idx))
            cx, cy = pts[idx]

            # Vertical dashed crosshair line
            v_line = ui.Path()
            v_line.move_to(cx, pad_t)
            v_line.line_to(cx, pad_t + plot_h)
            v_line.line_width = 1.0
            v_line.set_line_dash([2, 2])
            ui.set_color(ACCENT_BLUE)
            v_line.stroke()

            # Circle marker on curve
            dot = ui.Path.oval(cx - 4.5, cy - 4.5, 9, 9)
            ui.set_color(ACCENT_BLUE)
            dot.fill()
            dot_border = ui.Path.oval(cx - 4.5, cy - 4.5, 9, 9)
            dot_border.line_width = 1.5
            ui.set_color("#FFFFFF")
            dot_border.stroke()

    def touch_began(self, touch):
        self.touch_x = touch.location.x
        self._trigger_hover_at(touch.location.x)
        if hasattr(self, "set_needs_display"):
            self.set_needs_display()

    def touch_moved(self, touch):
        self.touch_x = touch.location.x
        self._trigger_hover_at(touch.location.x)
        if hasattr(self, "set_needs_display"):
            self.set_needs_display()

    def touch_ended(self, touch):
        self.touch_x = None
        if self.on_hover_callback:
            self.on_hover_callback(None, None)
        if hasattr(self, "set_needs_display"):
            self.set_needs_display()

    def _trigger_hover_at(self, tx: float):
        if not self.prices or not self.on_hover_callback:
            return
        w = self.width
        pad_l, pad_r = 14, 55
        plot_w = w - pad_l - pad_r
        if plot_w <= 0:
            return
        frac = (tx - pad_l) / plot_w
        idx = int(round(frac * (len(self.prices) - 1)))
        idx = max(0, min(len(self.prices) - 1, idx))
        p = self.prices[idx]
        t_val = self.timestamps[idx] if idx < len(self.timestamps) else ""
        self.on_hover_callback(p, t_val)


# =============================================================================
# 2. Holdings TableView Data Source
# =============================================================================
class HoldingsDataSource:
    def __init__(self, holdings: List[Dict[str, Any]], on_select_holding, on_delete_holding):
        self.holdings = holdings
        self.on_select_holding = on_select_holding
        self.on_delete_holding = on_delete_holding

    def tableview_number_of_sections(self, tableview):
        return 1

    def tableview_number_of_rows(self, tableview, section):
        return len(self.holdings)

    def tableview_cell_for_row(self, tableview, section, row):
        if not ui:
            return None
        h = self.holdings[row]
        cell = ui.TableViewCell("value1")
        cell.background_color = CARD_BG

        sym = str(h.get("symbol", "")).strip()
        name = str(h.get("name", "")).strip()
        shares = float(h.get("shares", 0.0) or 0.0)
        price = float(h.get("current_price", 0.0) or 0.0)
        curr = (h.get("currency") or "USD").strip().upper()
        sym_curr = "$" if curr in ("USD", "CAD") else (curr + " ")

        mv = float(h.get("market_value", 0.0) or (shares * price))
        gain_pct = float(h.get("unrealized_pl_pct", 0.0) or 0.0)
        gain_dlr = float(h.get("unrealized_pl", 0.0) or 0.0)
        is_pos = gain_pct >= 0

        # Primary label: Symbol & Name
        cell.text_label.text = f"{sym}"
        cell.text_label.text_color = TEXT_PRIMARY
        cell.text_label.font = ("<System-Bold>", 16)

        # Secondary detail label: Market Value & Return %
        sign = "+" if is_pos else ""
        detail_txt = f"{sym_curr}{mv:,.2f}\n{sign}{gain_pct:.2f}% ({sign}{sym_curr}{gain_dlr:,.2f})"
        cell.detail_text_label.text = detail_txt
        cell.detail_text_label.number_of_lines = 2
        cell.detail_text_label.text_color = ACCENT_GREEN if is_pos else ACCENT_RED
        cell.detail_text_label.font = ("<System>", 13)

        # Custom accessory view showing shares & buy price
        bp = float(h.get("buy_price", 0.0) or 0.0)
        port = h.get("portfolio", "Default")
        sub_lbl = ui.Label()
        sub_lbl.text = f"{name[:28]} · {shares:g} shs @ {sym_curr}{bp:,.2f} · {port}"
        sub_lbl.font = ("<System>", 11)
        sub_lbl.text_color = TEXT_SECONDARY
        sub_lbl.frame = (16, 42, 280, 16)
        cell.content_view.add_subview(sub_lbl)

        return cell

    def tableview_did_select(self, tableview, section, row):
        if row < len(self.holdings):
            self.on_select_holding(self.holdings[row])

    def tableview_can_delete(self, tableview, section, row):
        return True

    def tableview_delete(self, tableview, section, row):
        if row < len(self.holdings):
            self.on_delete_holding(self.holdings[row], row)


# =============================================================================
# 3. Watchlist TableView Data Source
# =============================================================================
class WatchlistDataSource:
    def __init__(self, watchlist: List[Dict[str, Any]], on_delete):
        self.watchlist = watchlist
        self.on_delete = on_delete

    def tableview_number_of_sections(self, tableview):
        return 1

    def tableview_number_of_rows(self, tableview, section):
        return len(self.watchlist)

    def tableview_cell_for_row(self, tableview, section, row):
        if not ui:
            return None
        item = self.watchlist[row]
        cell = ui.TableViewCell("value1")
        cell.background_color = CARD_BG

        sym = item.get("symbol", "")
        name = item.get("name", "")
        price = float(item.get("current_price", 0.0) or 0.0)
        target = float(item.get("target_price", 0.0) or 0.0)
        change_pct = float(item.get("day_change_pct", 0.0) or 0.0)

        cell.text_label.text = sym
        cell.text_label.text_color = TEXT_PRIMARY
        cell.text_label.font = ("<System-Bold>", 16)

        sub_txt = f"{name} · Target: ${target:,.2f}" if target > 0 else name
        sub_lbl = ui.Label()
        sub_lbl.text = sub_txt
        sub_lbl.font = ("<System>", 11)
        sub_lbl.text_color = TEXT_SECONDARY
        sub_lbl.frame = (16, 38, 250, 16)
        cell.content_view.add_subview(sub_lbl)

        sign = "+" if change_pct >= 0 else ""
        cell.detail_text_label.text = f"${price:,.2f}\n{sign}{change_pct:.2f}%"
        cell.detail_text_label.number_of_lines = 2
        cell.detail_text_label.text_color = ACCENT_GREEN if change_pct >= 0 else ACCENT_RED
        return cell

    def tableview_can_delete(self, tableview, section, row):
        return True

    def tableview_delete(self, tableview, section, row):
        self.on_delete(row)


# =============================================================================
# 4. History TableView Data Source
# =============================================================================
class HistoryDataSource:
    def __init__(self, transactions: List[Dict[str, Any]]):
        self.transactions = transactions

    def tableview_number_of_sections(self, tableview):
        return 1

    def tableview_number_of_rows(self, tableview, section):
        return len(self.transactions)

    def tableview_cell_for_row(self, tableview, section, row):
        if not ui:
            return None
        tx = self.transactions[row]
        cell = ui.TableViewCell("value1")
        cell.background_color = CARD_BG

        act = tx.get("action", tx.get("type", "BUY")).upper()
        sym = tx.get("symbol", "")
        shs = float(tx.get("shares", 0.0) or 0.0)
        pr = float(tx.get("price", 0.0) or 0.0)
        tot = float(tx.get("total", shs * pr) or 0.0)
        dt = tx.get("date", "")[:10]

        badge = "🟢 BUY" if act == "BUY" else ("🔴 SELL" if act == "SELL" else ("💧 DRIP" if act == "DRIP" else "💵 DIV"))
        cell.text_label.text = f"{badge}  {sym}"
        cell.text_label.text_color = TEXT_PRIMARY
        cell.text_label.font = ("<System-Bold>", 15)

        sub_lbl = ui.Label()
        sub_lbl.text = f"{dt} · {shs:g} shs @ ${pr:,.2f}"
        sub_lbl.font = ("<System>", 11)
        sub_lbl.text_color = TEXT_SECONDARY
        sub_lbl.frame = (16, 38, 250, 16)
        cell.content_view.add_subview(sub_lbl)

        cell.detail_text_label.text = f"${tot:,.2f}"
        cell.detail_text_label.text_color = TEXT_PRIMARY
        cell.detail_text_label.font = ("<System-Bold>", 14)
        return cell


# =============================================================================
# 5. Native Financial Calculator View
# =============================================================================
class CalculatorView(ui.View if ui else object):
    def __init__(self, *args, **kwargs):
        if ui:
            super().__init__(*args, **kwargs)
        self.background_color = BG_COLOR
        self.build_calc_ui()

    def build_calc_ui(self):
        if not ui:
            return
        w = max(320, self.width or 380)

        # Embedded scrollview for small screens
        self.scroll = ui.ScrollView(frame=self.bounds if hasattr(self, "bounds") else (0, 0, w, 480), flex="WH")
        self.scroll.content_size = (w, 500)
        self.scroll.background_color = BG_COLOR
        self.add_subview(self.scroll)

        # Tab Segment for Calculator mode
        self.seg = ui.SegmentedControl()
        self.seg.segments = ["Dividend & DRIP", "Target Sell Price", "Stock Split"]
        self.seg.selected_index = 0
        self.seg.frame = (16, 12, w - 32, 32)
        self.seg.action = self.on_mode_change
        self.scroll.add_subview(self.seg)

        # Container card
        self.card = ui.View()
        self.card.frame = (16, 56, w - 32, 390)
        self.card.background_color = CARD_BG
        self.card.corner_radius = 12
        self.scroll.add_subview(self.card)

        # Inputs inside card
        self.lbl_f1 = ui.Label(frame=(14, 14, 130, 24), text="Shares:", font=("<System>", 13), text_color=TEXT_SECONDARY)
        self.txt_f1 = ui.TextField(frame=(140, 12, 180, 30), text="100", keyboard_type=ui.KEYBOARD_DECIMAL_PAD)
        self.card.add_subview(self.lbl_f1)
        self.card.add_subview(self.txt_f1)

        self.lbl_f2 = ui.Label(frame=(14, 52, 130, 24), text="Current Price ($):", font=("<System>", 13), text_color=TEXT_SECONDARY)
        self.txt_f2 = ui.TextField(frame=(140, 50, 180, 30), text="150.00", keyboard_type=ui.KEYBOARD_DECIMAL_PAD)
        self.card.add_subview(self.lbl_f2)
        self.card.add_subview(self.txt_f2)

        self.lbl_f3 = ui.Label(frame=(14, 90, 130, 24), text="Annual Div/Share ($):", font=("<System>", 13), text_color=TEXT_SECONDARY)
        self.txt_f3 = ui.TextField(frame=(140, 88, 180, 30), text="4.50", keyboard_type=ui.KEYBOARD_DECIMAL_PAD)
        self.card.add_subview(self.lbl_f3)
        self.card.add_subview(self.txt_f3)

        self.lbl_f4 = ui.Label(frame=(14, 128, 130, 24), text="Years Horizon:", font=("<System>", 13), text_color=TEXT_SECONDARY)
        self.txt_f4 = ui.TextField(frame=(140, 126, 180, 30), text="10", keyboard_type=ui.KEYBOARD_NUMBER_PAD)
        self.card.add_subview(self.lbl_f4)
        self.card.add_subview(self.txt_f4)

        self.lbl_f5 = ui.Label(frame=(14, 166, 130, 24), text="Reinvest DRIP:", font=("<System>", 13), text_color=TEXT_SECONDARY)
        self.sw_drip = ui.Switch(frame=(140, 164, 51, 31))
        self.sw_drip.value = True
        self.card.add_subview(self.lbl_f5)
        self.card.add_subview(self.sw_drip)

        # Calculate Button
        btn_calc = ui.Button(frame=(14, 210, w - 60, 38))
        btn_calc.title = "Calculate Projection"
        btn_calc.background_color = ACCENT_BLUE
        btn_calc.tint_color = "#FFFFFF"
        btn_calc.corner_radius = 8
        btn_calc.font = ("<System-Bold>", 15)
        btn_calc.action = self.do_calculate
        self.card.add_subview(btn_calc)

        # Result Display Area
        self.lbl_result = ui.Label(frame=(14, 258, w - 60, 110))
        self.lbl_result.number_of_lines = 5
        self.lbl_result.font = ("<System>", 13)
        self.lbl_result.text_color = ACCENT_GREEN
        self.lbl_result.text = "Tap 'Calculate Projection' to run simulation."
        self.card.add_subview(self.lbl_result)

    def on_mode_change(self, sender):
        idx = sender.selected_index
        if idx == 0:  # Dividend & DRIP
            self.lbl_f1.text = "Shares:"
            self.lbl_f2.text = "Price ($):"
            self.lbl_f3.text = "Annual Div ($):"
            self.lbl_f4.text = "Years:"
            self.lbl_f5.hidden = False
            self.sw_drip.hidden = False
        elif idx == 1:  # Target Sell Price
            self.lbl_f1.text = "Shares:"
            self.lbl_f2.text = "Buy Price ($):"
            self.lbl_f3.text = "Target Profit %:"
            self.lbl_f4.text = "Commission ($):"
            self.lbl_f5.hidden = True
            self.sw_drip.hidden = True
        else:  # Stock Split
            self.lbl_f1.text = "Current Shares:"
            self.lbl_f2.text = "Current Price ($):"
            self.lbl_f3.text = "Split Ratio (e.g. 2):"
            self.lbl_f4.text = "Reverse (1=No):"
            self.lbl_f5.hidden = True
            self.sw_drip.hidden = True
        self.lbl_result.text = "Ready to calculate."

    def do_calculate(self, sender):
        idx = self.seg.selected_index
        try:
            f1 = float(self.txt_f1.text or 0.0)
            f2 = float(self.txt_f2.text or 0.0)
            f3 = float(self.txt_f3.text or 0.0)
            f4 = float(self.txt_f4.text or 0.0)
        except ValueError:
            self.lbl_result.text = "Please enter valid numbers."
            return

        if idx == 0:
            # DRIP calculation
            res = financial_calc.calc_drip_simulation(
                current_shares=f1,
                current_price=f2,
                annual_dividend_per_share=f3,
                years=int(f4),
                dividend_growth_rate=0.05,
                stock_growth_rate=0.07,
                reinvest_dividends=self.sw_drip.value,
            )
            val = res.get("final_portfolio_value", 0.0)
            divs = res.get("total_dividends_earned", 0.0)
            shs = res.get("final_shares", 0.0)
            ann = res.get("final_annual_dividend_income", 0.0)
            self.lbl_result.text = (
                f"📈 Final Value: ${val:,.2f}\n"
                f"💵 Total Dividends Earned: ${divs:,.2f}\n"
                f"📊 Final Shares: {shs:,.2f} shs\n"
                f"💰 Year {int(f4)} Annual Income: ${ann:,.2f}/yr"
            )
        elif idx == 1:
            # Target sell price calculation
            res = financial_calc.calc_target_profit_sell_price(
                shares=f1,
                buy_price=f2,
                target_profit_pct=f3,
                commission_fee=f4,
            )
            tp = res.get("target_sell_price", 0.0)
            gain = res.get("target_capital_gain", 0.0)
            proceeds = res.get("total_net_proceeds", 0.0)
            self.lbl_result.text = (
                f"🎯 Target Sell Price: ${tp:,.2f}\n"
                f"💵 Target Net Profit: ${gain:,.2f}\n"
                f"💰 Total Proceeds: ${proceeds:,.2f}\n"
                f"📊 Cost Basis: ${f1 * f2:,.2f}"
            )
        else:
            # Split calculation
            ratio = max(1.0, f3)
            new_shs = f1 * ratio
            new_p = f2 / ratio
            self.lbl_result.text = (
                f"✂️ Post-Split Shares: {new_shs:,.2f} shs\n"
                f"🏷️ Post-Split Price: ${new_p:,.2f}\n"
                f"💰 Total Value: ${new_shs * new_p:,.2f} (Unchanged)"
            )


# =============================================================================
# 6. Main Native Pythonista App Container View
# =============================================================================
class GFinanceNativeApp(ui.View if ui else object):
    """Full-screen native iOS Application for Pythonista 3."""

    def __init__(self, *args, **kwargs):
        if ui:
            super().__init__(*args, **kwargs)
        self.name = "G_Finance Portfolio"
        self.background_color = BG_COLOR
        self.tint_color = ACCENT_BLUE

        self.portfolios = ["All Portfolios"]
        self.current_portfolio = "All Portfolios"
        self.holdings = []
        self.watchlist = []
        self.transactions = []
        self.selected_timeframe = "1M"

        self.build_ui()
        self.load_data()

    def build_ui(self):
        if not ui:
            return
        w = max(320, self.width or 380)

        # 1. Top Bar Navigation Buttons
        btn_refresh = ui.ButtonItem(title="⟳ Refresh")
        btn_refresh.action = self.on_refresh_quotes
        btn_add = ui.ButtonItem(title="+ Add")
        btn_add.action = self.on_add_holding
        btn_sync = ui.ButtonItem(title="☁️ Sync")
        btn_sync.action = self.on_google_sheet_sync
        self.right_button_items = [btn_refresh, btn_add, btn_sync]

        # 2. Portfolio Switcher Pill / Header
        self.btn_port = ui.Button(frame=(14, 8, w - 28, 30))
        self.btn_port.title = f"📁 {self.current_portfolio}  ▾"
        self.btn_port.font = ("<System-Bold>", 15)
        self.btn_port.tint_color = ACCENT_BLUE
        self.btn_port.background_color = CARD_BG
        self.btn_port.corner_radius = 8
        self.btn_port.action = self.on_select_portfolio
        self.add_subview(self.btn_port)

        # 3. Portfolio Summary Card (Card UI)
        self.summary_card = ui.View(frame=(14, 46, w - 28, 86))
        self.summary_card.background_color = CARD_BG
        self.summary_card.corner_radius = 12
        self.add_subview(self.summary_card)

        self.lbl_total_val = ui.Label(frame=(12, 8, w - 52, 28))
        self.lbl_total_val.text = "$0.00"
        self.lbl_total_val.font = ("<System-Bold>", 24)
        self.lbl_total_val.text_color = TEXT_PRIMARY
        self.summary_card.add_subview(self.lbl_total_val)

        self.lbl_total_sub = ui.Label(frame=(12, 38, w - 52, 20))
        self.lbl_total_sub.text = "+$0.00 (+0.00%) · Cost: $0.00"
        self.lbl_total_sub.font = ("<System-Bold>", 13)
        self.lbl_total_sub.text_color = ACCENT_GREEN
        self.summary_card.add_subview(self.lbl_total_sub)

        self.lbl_div_sub = ui.Label(frame=(12, 60, w - 52, 18))
        self.lbl_div_sub.text = "💵 Est. Annual Dividend: $0.00 · Yield: 0.00%"
        self.lbl_div_sub.font = ("<System>", 11)
        self.lbl_div_sub.text_color = TEXT_SECONDARY
        self.summary_card.add_subview(self.lbl_div_sub)

        # 4. Main Segmented Tab Switcher
        self.main_seg = ui.SegmentedControl(frame=(14, 140, w - 28, 32))
        self.main_seg.segments = ["Holdings", "Chart", "Calc", "Watchlist", "History"]
        self.main_seg.selected_index = 0
        self.main_seg.action = self.on_main_tab_changed
        self.add_subview(self.main_seg)

        # 5. Tab Content Container View
        self.content_container = ui.View(frame=(14, 180, w - 28, 460))
        self.content_container.background_color = BG_COLOR
        self.content_container.flex = "WH"
        self.add_subview(self.content_container)

        # Subview 5a: Holdings TableView
        self.holdings_tv = ui.TableView(frame=(0, 0, self.content_container.width, self.content_container.height))
        self.holdings_tv.flex = "WH"
        self.holdings_tv.row_height = 68
        self.holdings_tv.background_color = BG_COLOR
        self.holdings_tv.separator_color = SEPARATOR_COLOR
        self.content_container.add_subview(self.holdings_tv)

        # Subview 5b: Chart View with Timeframe Pills
        self.chart_container = ui.View(frame=(0, 0, self.content_container.width, self.content_container.height))
        self.chart_container.flex = "WH"
        self.chart_container.hidden = True
        self.content_container.add_subview(self.chart_container)

        self.chart_tf_seg = ui.SegmentedControl(frame=(0, 4, self.chart_container.width, 28))
        self.chart_tf_seg.segments = ["1D", "5D", "1M", "6M", "YTD", "1Y", "MAX"]
        self.chart_tf_seg.selected_index = 2
        self.chart_tf_seg.action = self.on_timeframe_changed
        self.chart_container.add_subview(self.chart_tf_seg)

        self.native_chart = NativeChartView(frame=(0, 40, self.chart_container.width, 280))
        self.native_chart.flex = "W"
        self.native_chart.on_hover_callback = self.on_chart_hover
        self.chart_container.add_subview(self.native_chart)

        self.lbl_chart_hover = ui.Label(frame=(0, 328, self.chart_container.width, 24))
        self.lbl_chart_hover.font = ("<System>", 12)
        self.lbl_chart_hover.text_color = TEXT_SECONDARY
        self.lbl_chart_hover.alignment = ui.ALIGN_CENTER
        self.chart_container.add_subview(self.lbl_chart_hover)

        # Subview 5c: Calculator View
        self.calc_view = CalculatorView(frame=(0, 0, self.content_container.width, self.content_container.height))
        self.calc_view.flex = "WH"
        self.calc_view.hidden = True
        self.content_container.add_subview(self.calc_view)

        # Subview 5d: Watchlist TableView
        self.watchlist_tv = ui.TableView(frame=(0, 0, self.content_container.width, self.content_container.height))
        self.watchlist_tv.flex = "WH"
        self.watchlist_tv.row_height = 60
        self.watchlist_tv.background_color = BG_COLOR
        self.watchlist_tv.separator_color = SEPARATOR_COLOR
        self.watchlist_tv.hidden = True
        self.content_container.add_subview(self.watchlist_tv)

        # Subview 5e: History TableView
        self.history_tv = ui.TableView(frame=(0, 0, self.content_container.width, self.content_container.height))
        self.history_tv.flex = "WH"
        self.history_tv.row_height = 60
        self.history_tv.background_color = BG_COLOR
        self.history_tv.separator_color = SEPARATOR_COLOR
        self.history_tv.hidden = True
        self.content_container.add_subview(self.history_tv)

    def load_data(self):
        """Loads all portfolio, watchlist, and transaction data from disk."""
        try:
            self.portfolios = ["All Portfolios"] + [p for p in csv_manager.get_portfolio_names() if p != "All Portfolios"]
        except Exception:
            self.portfolios = ["All Portfolios"]

        p_name = None if self.current_portfolio == "All Portfolios" else self.current_portfolio
        self.holdings = csv_manager.load_portfolio(portfolio_name=p_name)
        self.watchlist = csv_manager.load_watchlist()
        self.transactions = csv_manager.load_transactions()

        # Update summary card
        self._update_summary_card()

        # Update Holdings TableView
        self.holdings_ds = HoldingsDataSource(self.holdings, self.show_holding_details, self.delete_holding_action)
        self.holdings_tv.data_source = self.holdings_ds
        self.holdings_tv.delegate = self.holdings_ds
        self.holdings_tv.reload()

        # Update Watchlist TableView
        self.watchlist_ds = WatchlistDataSource(self.watchlist, self.delete_watchlist_action)
        self.watchlist_tv.data_source = self.watchlist_ds
        self.watchlist_tv.delegate = self.watchlist_ds
        self.watchlist_tv.reload()

        # Update History TableView
        self.history_ds = HistoryDataSource(self.transactions)
        self.history_tv.data_source = self.history_ds
        self.history_tv.delegate = self.history_ds
        self.history_tv.reload()

        # Load chart data asynchronously
        threading.Thread(target=self._fetch_chart_data_async, daemon=True).start()

    def _update_summary_card(self):
        tot_mv = 0.0
        tot_cb = 0.0
        tot_div = 0.0
        for h in self.holdings:
            shs = float(h.get("shares", 0.0) or 0.0)
            bp = float(h.get("buy_price", 0.0) or 0.0)
            cp = float(h.get("current_price", bp) or bp)
            cb = float(h.get("cost_basis", shs * bp) or (shs * bp))
            mv = float(h.get("market_value", shs * cp) or (shs * cp))
            ann_d = float(h.get("annual_dividend", 0.0) or 0.0)
            tot_cb += cb
            tot_mv += mv
            tot_div += ann_d

        gain = tot_mv - tot_cb
        gain_pct = (gain / tot_cb * 100) if tot_cb > 0 else 0.0
        yield_pct = (tot_div / tot_mv * 100) if tot_mv > 0 else 0.0
        is_pos = gain >= 0
        sign = "+" if is_pos else ""

        self.lbl_total_val.text = f"${tot_mv:,.2f}"
        self.lbl_total_sub.text = f"{sign}${gain:,.2f} ({sign}{gain_pct:.2f}%) · Cost: ${tot_cb:,.2f}"
        self.lbl_total_sub.text_color = ACCENT_GREEN if is_pos else ACCENT_RED
        self.lbl_div_sub.text = f"💵 Est. Annual Dividend: ${tot_div:,.2f} · Yield: {yield_pct:.2f}%"

    def on_main_tab_changed(self, sender):
        idx = sender.selected_index
        self.holdings_tv.hidden = (idx != 0)
        self.chart_container.hidden = (idx != 1)
        self.calc_view.hidden = (idx != 2)
        self.watchlist_tv.hidden = (idx != 3)
        self.history_tv.hidden = (idx != 4)

    def on_timeframe_changed(self, sender):
        tfs = ["1D", "5D", "1M", "6M", "YTD", "1Y", "MAX"]
        self.selected_timeframe = tfs[sender.selected_index]
        threading.Thread(target=self._fetch_chart_data_async, daemon=True).start()

    def _fetch_chart_data_async(self):
        fetcher = get_chart_fetcher()
        p_name = self.current_portfolio
        data = fetcher.fetch_portfolio_history(
            holdings=self.holdings,
            portfolio_name=p_name,
            timeframe=self.selected_timeframe,
        )
        if data and data.get("prices"):
            self.native_chart.set_data(
                prices=data.get("prices", []),
                timestamps=data.get("timestamps", []),
                prev_close=data.get("prev_close", 0.0),
                currency_sym="$",
            )
            latest_p = data["prices"][-1]
            prev_p = data.get("prev_close", data["prices"][0])
            diff = latest_p - prev_p
            pct = (diff / prev_p * 100) if prev_p > 0 else 0.0
            sign = "+" if diff >= 0 else ""
            self.lbl_chart_hover.text = f"{self.selected_timeframe} Close: ${latest_p:,.2f} ({sign}{pct:.2f}%)"

    def on_chart_hover(self, price: Optional[float], timestamp: Any):
        if price is not None:
            dt_str = str(timestamp)[:16] if timestamp else ""
            self.lbl_chart_hover.text = f"Touch: ${price:,.2f} ({dt_str})"
        else:
            self.lbl_chart_hover.text = f"{self.selected_timeframe} Portfolio Curve"

    def on_select_portfolio(self, sender):
        if dialogs:
            chosen = dialogs.list_dialog("Select Portfolio", self.portfolios)
            if chosen:
                self.current_portfolio = chosen
                self.btn_port.title = f"📁 {chosen}  ▾"
                self.load_data()
        else:
            # Cycle through portfolios if dialogs module not available
            curr_idx = self.portfolios.index(self.current_portfolio) if self.current_portfolio in self.portfolios else 0
            next_idx = (curr_idx + 1) % len(self.portfolios)
            self.current_portfolio = self.portfolios[next_idx]
            self.btn_port.title = f"📁 {self.current_portfolio}  ▾"
            self.load_data()

    def on_add_holding(self, sender):
        if dialogs:
            fields = [
                {"type": "text", "title": "Symbol", "key": "symbol", "placeholder": "e.g. VOO or VFV"},
                {"type": "number", "title": "Shares", "key": "shares", "placeholder": "10.0"},
                {"type": "number", "title": "Buy Price", "key": "buy_price", "placeholder": "150.0"},
                {"type": "text", "title": "Currency", "key": "currency", "value": "USD"},
                {"type": "text", "title": "Portfolio", "key": "portfolio", "value": self.current_portfolio if self.current_portfolio != "All Portfolios" else "USD HSBC"},
            ]
            res = dialogs.form_dialog("Add Stock Holding", fields)
            if res and res.get("symbol"):
                sym = res["symbol"].strip().upper()
                shs = float(res.get("shares") or 1.0)
                bp = float(res.get("buy_price") or 0.0)
                curr = (res.get("currency") or "USD").strip().upper()
                port = res.get("portfolio") or "USD HSBC"

                # Save holding
                holding_data = {
                    "portfolio": port,
                    "symbol": sym,
                    "shares": shs,
                    "buy_price": bp,
                    "current_price": bp,
                    "currency": curr,
                }
                csv_manager.add_holding(holding_data)
                # Log transaction
                csv_manager.append_transaction({
                    "date": time.strftime("%Y-%m-%d %H:%M:%S"),
                    "action": "BUY",
                    "symbol": sym,
                    "shares": shs,
                    "price": bp,
                    "total": shs * bp,
                    "portfolio": port,
                    "currency": curr,
                })
                if console:
                    console.hud_alert(f"Added {sym}", "success", 1.0)
                self.load_data()

    def show_holding_details(self, holding: Dict[str, Any]):
        """Presents a native iOS sheet showing full holding stats & buy/sell/delete actions."""
        if not ui:
            return
        sym = holding.get("symbol", "")
        name = holding.get("name", "")
        shs = float(holding.get("shares", 0.0) or 0.0)
        bp = float(holding.get("buy_price", 0.0) or 0.0)
        cp = float(holding.get("current_price", 0.0) or 0.0)
        mv = float(holding.get("market_value", 0.0) or (shs * cp))
        cb = float(holding.get("cost_basis", 0.0) or (shs * bp))
        gain = mv - cb
        gain_pct = (gain / cb * 100) if cb > 0 else 0.0
        ann_d = float(holding.get("annual_dividend", 0.0) or 0.0)
        port = holding.get("portfolio", "")

        sheet = ui.View(frame=(0, 0, 360, 480))
        sheet.name = f"{sym} Details"
        sheet.background_color = CARD_BG

        info_tv = ui.TextView(frame=(14, 14, 332, 280))
        info_tv.background_color = CARD_SECONDARY
        info_tv.text_color = TEXT_PRIMARY
        info_tv.font = ("<System>", 14)
        info_tv.editable = False
        info_tv.corner_radius = 8
        sign = "+" if gain >= 0 else ""
        info_tv.text = (
            f"Symbol: {sym} ({name})\n"
            f"Portfolio: {port}\n"
            f"Shares Held: {shs:g} shs\n"
            f"Buy Price: ${bp:,.2f}\n"
            f"Current Price: ${cp:,.2f}\n"
            f"Total Cost Basis: ${cb:,.2f}\n"
            f"Market Value: ${mv:,.2f}\n"
            f"Unrealized P/L: {sign}${gain:,.2f} ({sign}{gain_pct:.2f}%)\n"
            f"Est. Annual Dividends: ${ann_d:,.2f}\n"
            f"Currency: {holding.get('currency', 'USD')}"
        )
        sheet.add_subview(info_tv)

        # Action: Sell Shares
        btn_sell = ui.Button(frame=(14, 306, 332, 40))
        btn_sell.title = "💰 Sell Shares (Record Sale)"
        btn_sell.background_color = ACCENT_RED
        btn_sell.tint_color = "#FFFFFF"
        btn_sell.corner_radius = 8
        btn_sell.font = ("<System-Bold>", 15)

        def do_sell(sender):
            if dialogs:
                res = dialogs.form_dialog(f"Sell {sym}", [
                    {"type": "number", "title": "Shares to Sell", "key": "shares", "value": str(shs)},
                    {"type": "number", "title": "Sell Price", "key": "price", "value": str(cp)},
                ])
                if res and float(res.get("shares") or 0.0) > 0:
                    sell_shs = float(res["shares"])
                    sell_p = float(res.get("price") or cp)
                    csv_manager.append_sale_record({
                        "portfolio": port,
                        "symbol": sym,
                        "shares_sold": sell_shs,
                        "buy_price": bp,
                        "sell_price": sell_p,
                        "proceeds": sell_shs * sell_p,
                        "realized_gain": sell_shs * (sell_p - bp),
                        "date": time.strftime("%Y-%m-%d %H:%M:%S"),
                    })
                    rem_shs = shs - sell_shs
                    if rem_shs > 0:
                        csv_manager.update_holding(sym, {"shares": rem_shs}, portfolio_name=port)
                    else:
                        csv_manager.delete_holding(sym, portfolio_name=port)
                    if console:
                        console.hud_alert("Sale Recorded!", "success", 1.0)
                    sheet.close()
                    self.load_data()

        btn_sell.action = do_sell
        sheet.add_subview(btn_sell)

        # Action: Close
        btn_close = ui.Button(frame=(14, 354, 332, 40))
        btn_close.title = "Done"
        btn_close.background_color = CARD_SECONDARY
        btn_close.tint_color = ACCENT_BLUE
        btn_close.corner_radius = 8
        btn_close.action = lambda s: sheet.close()
        sheet.add_subview(btn_close)

        sheet.present("sheet")

    def delete_holding_action(self, holding: Dict[str, Any], row_idx: int):
        sym = holding.get("symbol", "")
        port = holding.get("portfolio", "")
        csv_manager.delete_holding(sym, portfolio_name=port)
        if console:
            console.hud_alert(f"Deleted {sym}", "success", 1.0)
        self.load_data()

    def delete_watchlist_action(self, row_idx: int):
        if row_idx < len(self.watchlist):
            item = self.watchlist[row_idx]
            sym = item.get("symbol", "")
            csv_manager.remove_from_watchlist(sym)
            if console:
                console.hud_alert(f"Removed {sym}", "success", 1.0)
            self.load_data()

    def on_refresh_quotes(self, sender):
        if console:
            console.hud_alert("Fetching latest quotes...", "none", 1.0)

        def _worker():
            try:
                fetcher = GoogleFinanceFetcher()
                symbols = list({h.get("symbol", "") for h in self.holdings if h.get("symbol")})
                quotes = fetcher.fetch_quotes(symbols)
                for h in self.holdings:
                    s = h.get("symbol")
                    if s in quotes and quotes[s].get("price"):
                        q = quotes[s]
                        h["current_price"] = q["price"]
                        h["day_change"] = q.get("change_pct", "+0.00%")
                        shs = float(h.get("shares", 0.0) or 0.0)
                        h["market_value"] = shs * q["price"]
                csv_manager.save_portfolio(self.holdings)
                if console:
                    console.hud_alert("Quotes updated!", "success", 1.0)
                self.load_data()
            except Exception as e:
                if console:
                    console.hud_alert(f"Quote error: {e}", "error", 1.5)

        threading.Thread(target=_worker, daemon=True).start()

    def on_google_sheet_sync(self, sender):
        if console:
            console.hud_alert("Syncing Google Sheet...", "none", 1.0)

        def _worker():
            try:
                sync = get_google_sheet_sync()
                res = sync.perform_sync()
                msg = res.get("message", "Sync complete") if isinstance(res, dict) else "Sync complete"
                is_ok = res.get("success", False) if isinstance(res, dict) else True
                if console:
                    console.hud_alert(msg, "success" if is_ok else "error", 1.5)
                self.load_data()
            except Exception as e:
                if console:
                    console.hud_alert(f"Sync error: {e}", "error", 2.0)

        threading.Thread(target=_worker, daemon=True).start()


def main():
    """Entry point for running the pure native iOS Pythonista 3 application."""
    if not PYTHONISTA_UI_AVAILABLE:
        print("Pythonista `ui` module not available on this desktop OS.")
        print("Run `python main_gui.py` on desktop, or run this script inside Pythonista 3 on iOS.")
        return

    app = GFinanceNativeApp()
    app.present("fullscreen", hide_title_bar=False)


if __name__ == "__main__":
    main()
